var config = {
    masterBgColor: "#202228",
    bgColor: "#282D33",
    bgLinesColor: "#202228",
    bgOutColor: "#3f424a",
    zoomScale:0.001,
    zoomLimits:{min:0.2, max:4},
    tileSize:1,
    GUITileSize:32,
    gridSize:{x:50, y:50},
    GUIWidth:0,
    GUISelectBlocksWidth:32*8+8*9,
    GUIBgColor:"#16181c",
    GUIMargin:8,
    GUIY:100,
    blockLayers: 1,
    canvasRefreshTime: 20, //50 FP
    textColor1: "#848891",
    textColor2: "#3f424a",
    historySize: 20,
    hoverResizeColor: "#ffffff"
}

export default config;