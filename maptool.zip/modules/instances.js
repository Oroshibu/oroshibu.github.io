import { Block, Entity, Pof, Node } from "./classes.js";

var instances = {};

export default instances;

instances["pof"] = new Pof();
instances["node"] = new Node();