var config_ludogram = {
    IMAGE_SOURCE: "images/source.jpg",
    POF_ANCHOR_OFFSET:{x:-36, y:-36},
    POF_SIZE:{width:320, height:320},
    NODE_ANCHOR_OFFSET:{x:0, y:0},
    NODE_SIZE:20,
    PATH_WIDTH:10,
    ZOOM_LIMITS:{min:0.2, max:1.5},
    STARTING_ZOOM: 0.2,
    IDLE_COLOR : "#000000",
    SELECTED_COLOR : "#ff0000",
    MAP_DIRECTION : {x:1, y:-1}
}

export default config_ludogram;